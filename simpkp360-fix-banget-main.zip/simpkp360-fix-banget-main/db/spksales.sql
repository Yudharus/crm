-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 09, 2022 at 10:07 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.0.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `spksales`
--

-- --------------------------------------------------------

--
-- Table structure for table `isi_kompetensi`
--

CREATE TABLE `isi_kompetensi` (
  `id_isi` int(11) NOT NULL,
  `id_kompetensi` int(11) DEFAULT NULL,
  `isi_kompetensi` text DEFAULT NULL,
  `ket` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `isi_kompetensi`
--

INSERT INTO `isi_kompetensi` (`id_isi`, `id_kompetensi`, `isi_kompetensi`, `ket`) VALUES
(26, 8, 'Sikap Mental (Attitude) &amp; Motivasi Kerja', '0'),
(27, 8, 'Aktif dan Berani Mengemukakan Pendapat', '0'),
(28, 8, 'Kreatifitas', '0'),
(29, 9, 'Hubungan Baik Internal &amp; Eksternal', '0,1'),
(30, 9, 'Komunikasi Internal &amp; Eksternal', '0,1'),
(31, 9, 'Negosiasi &amp; Deal Sales ', '0,1'),
(32, 9, 'Pencapaian Target Kegiatan Bulanan', '0,1'),
(33, 10, 'Mencari Peluang Pasar Baru', '0,1,2'),
(34, 10, 'Ketepatan Laporan', '0,1,2'),
(35, 10, 'Penguasaan Area &amp; Pengetahuan Produk', '0,1,2');

-- --------------------------------------------------------

--
-- Table structure for table `jenis_kompetensi`
--

CREATE TABLE `jenis_kompetensi` (
  `id_kompetensi` int(11) NOT NULL,
  `nama_kompetensi` varchar(50) DEFAULT '0',
  `bobot_kompetensi` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jenis_kompetensi`
--

INSERT INTO `jenis_kompetensi` (`id_kompetensi`, `nama_kompetensi`, `bobot_kompetensi`) VALUES
(8, 'Kepribadian', 20),
(9, 'Objektif Bisnis', 50),
(10, 'Keterampilan', 30);

-- --------------------------------------------------------

--
-- Table structure for table `jenis_user`
--

CREATE TABLE `jenis_user` (
  `id_jenis_user` int(10) NOT NULL,
  `jabatan` varchar(20) DEFAULT NULL,
  `level` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jenis_user`
--

INSERT INTO `jenis_user` (`id_jenis_user`, `jabatan`, `level`) VALUES
(0, 'Regional Sales Manag', 0),
(3, 'Pegawai', 1),
(6, 'Territory Manager', 1),
(7, 'DSR', 1),
(8, 'Feasibility Study', 1),
(9, 'CAC', 1),
(10, 'Admin', 1),
(11, 'test', 1);

-- --------------------------------------------------------

--
-- Table structure for table `penilai`
--

CREATE TABLE `penilai` (
  `id_penilai` int(11) NOT NULL,
  `nip` char(18) DEFAULT NULL,
  `id_periode` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `penilai`
--

INSERT INTO `penilai` (`id_penilai`, `nip`, `id_periode`) VALUES
(117, '101010', 7),
(128, '10118040', 7),
(129, '10118003', 7);

-- --------------------------------------------------------

--
-- Table structure for table `penilaian`
--

CREATE TABLE `penilaian` (
  `id_nilai` int(11) NOT NULL,
  `id_penilai_detail` int(11) DEFAULT NULL,
  `id_isi` int(11) DEFAULT NULL,
  `hasil_nilai` double(11,1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `penilaian`
--

INSERT INTO `penilaian` (`id_nilai`, `id_penilai_detail`, `id_isi`, `hasil_nilai`) VALUES
(2177, 360, 26, 0.7),
(2178, 360, 27, 0.4),
(2179, 360, 28, 0.4),
(2180, 360, 29, 0.7),
(2181, 360, 30, 0.8),
(2182, 360, 31, 0.7),
(2183, 360, 32, 1.6),
(2184, 360, 33, 0.7),
(2185, 360, 34, 0.8),
(2186, 360, 35, 0.8),
(2187, 361, 29, 0.8),
(2188, 361, 30, 0.8),
(2189, 361, 31, 0.8),
(2190, 361, 32, 1.4),
(2191, 361, 33, 1.4),
(2192, 361, 34, 1.2),
(2193, 361, 35, 1.4),
(2392, 387, 26, 0.9),
(2393, 387, 27, 0.4),
(2394, 387, 28, 0.3),
(2395, 387, 29, 0.9),
(2396, 387, 30, 0.9),
(2397, 387, 31, 0.7),
(2398, 387, 32, 1.6),
(2399, 387, 33, 0.8),
(2400, 387, 34, 0.8),
(2401, 387, 35, 0.9),
(2402, 389, 26, 0.7),
(2403, 389, 27, 0.3),
(2404, 389, 28, 0.4),
(2405, 389, 29, 0.8),
(2406, 389, 30, 0.8),
(2407, 389, 31, 0.7),
(2408, 389, 32, 1.4),
(2409, 389, 33, 0.9),
(2410, 389, 34, 0.8),
(2411, 389, 35, 0.8),
(2412, 388, 29, 0.7),
(2413, 388, 30, 0.7),
(2414, 388, 31, 0.7),
(2415, 388, 32, 1.2),
(2416, 388, 33, 1.6),
(2417, 388, 34, 1.2),
(2418, 388, 35, 1.4),
(2419, 391, 29, 0.7),
(2420, 391, 30, 0.7),
(2421, 391, 31, 0.7),
(2422, 391, 32, 1.6),
(2423, 391, 33, 1.6),
(2424, 391, 34, 1.2),
(2425, 391, 35, 1.2),
(2426, 390, 29, 0.7),
(2427, 390, 30, 0.7),
(2428, 390, 31, 0.6),
(2429, 390, 32, 1.2),
(2430, 390, 33, 1.6),
(2431, 390, 34, 1.4),
(2432, 390, 35, 1.4);

-- --------------------------------------------------------

--
-- Table structure for table `penilai_detail`
--

CREATE TABLE `penilai_detail` (
  `id_penilai_detail` int(11) NOT NULL,
  `id_penilai` int(11) NOT NULL,
  `nip` char(16) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `penilai_detail`
--

INSERT INTO `penilai_detail` (`id_penilai_detail`, `id_penilai`, `nip`) VALUES
(360, 117, '1991011020201003'),
(361, 117, '11111'),
(387, 128, '1991011020201003'),
(388, 128, '13123123123'),
(389, 129, '1991011020201003'),
(390, 129, '10118040'),
(391, 129, '13123123123');

-- --------------------------------------------------------

--
-- Table structure for table `periode`
--

CREATE TABLE `periode` (
  `id_periode` int(11) NOT NULL,
  `tahun` varchar(50) NOT NULL,
  `kwartal` varchar(50) NOT NULL,
  `status_periode` int(11) NOT NULL,
  `setting` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `periode`
--

INSERT INTO `periode` (`id_periode`, `tahun`, `kwartal`, `status_periode`, `setting`) VALUES
(7, '2022', '', 1, '20;30;50');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `nip` char(18) NOT NULL,
  `id_jenis_user` int(11) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `nama_pegawai` varchar(100) DEFAULT NULL,
  `status_pegawai` varchar(100) DEFAULT NULL,
  `alamat` text DEFAULT NULL,
  `tempat_lahir` varchar(100) DEFAULT NULL,
  `tgl_lahir` date DEFAULT NULL,
  `jenis_kelamin` char(1) DEFAULT NULL,
  `status_nikah` char(1) DEFAULT NULL,
  `no_telp` varchar(20) DEFAULT NULL,
  `area_kerja` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`nip`, `id_jenis_user`, `password`, `nama_pegawai`, `status_pegawai`, `alamat`, `tempat_lahir`, `tgl_lahir`, `jenis_kelamin`, `status_nikah`, `no_telp`, `area_kerja`) VALUES
('101010', 7, '12345', 'Jaya Saputra', 'TETAP', 'bandung', 'Bandung', '2022-07-08', '', '', '08723767781', 'Cirebon'),
('10118003', 3, '12345', 'Aria', 'asdasd', 'asdasd', 'asdasdasda', '2022-07-08', 'L', 'B', '123123', 'Bandung'),
('10118040', 10, '12345', 'yudha', 'tetap', 'asdasdasd', 'bbb', '2022-07-08', '', '', '1231231312', 'bANDUNG'),
('11111', 7, '12345', 'Indriyeni', 'TETAP', 'bandung', 'bandung', '2022-07-08', 'P', 'N', '123123123123', 'Cirebon'),
('13123123123', 3, '12345', 'rama', 'asdasdas', 'dasdasdasd', 'asdasdasdasda', '2022-07-08', 'L', 'B', '123123', 'bandung'),
('141414141', 11, '12345', 'testtttttt', 'asdasd', 'asdasd', 'adsasdasdasd', '2022-08-08', 'L', 'B', '123123123', 'asdasdas'),
('1991011020201003', 0, 'manager', 'Edi R Gumilar', 'Tetap', 'Bandung', 'Bandung', '1990-08-31', 'L', 'B', '08974650548', ''),
('55675644', 3, '12345', 'guntur', 'asdasdas', 'dasdas', 'dasdasd', '2022-07-08', 'L', 'B', '123123123', 'asdasdas');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `isi_kompetensi`
--
ALTER TABLE `isi_kompetensi`
  ADD PRIMARY KEY (`id_isi`),
  ADD KEY `id_kompetensi` (`id_kompetensi`);

--
-- Indexes for table `jenis_kompetensi`
--
ALTER TABLE `jenis_kompetensi`
  ADD PRIMARY KEY (`id_kompetensi`);

--
-- Indexes for table `jenis_user`
--
ALTER TABLE `jenis_user`
  ADD PRIMARY KEY (`id_jenis_user`);

--
-- Indexes for table `penilai`
--
ALTER TABLE `penilai`
  ADD PRIMARY KEY (`id_penilai`),
  ADD KEY `nip` (`nip`),
  ADD KEY `id_periode` (`id_periode`);

--
-- Indexes for table `penilaian`
--
ALTER TABLE `penilaian`
  ADD PRIMARY KEY (`id_nilai`),
  ADD KEY `id_isi` (`id_isi`),
  ADD KEY `id_penilai_detail` (`id_penilai_detail`);

--
-- Indexes for table `penilai_detail`
--
ALTER TABLE `penilai_detail`
  ADD PRIMARY KEY (`id_penilai_detail`),
  ADD KEY `id_penilai` (`id_penilai`),
  ADD KEY `nip` (`nip`);

--
-- Indexes for table `periode`
--
ALTER TABLE `periode`
  ADD PRIMARY KEY (`id_periode`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`nip`),
  ADD KEY `id_jenis_user` (`id_jenis_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `isi_kompetensi`
--
ALTER TABLE `isi_kompetensi`
  MODIFY `id_isi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `jenis_kompetensi`
--
ALTER TABLE `jenis_kompetensi`
  MODIFY `id_kompetensi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `jenis_user`
--
ALTER TABLE `jenis_user`
  MODIFY `id_jenis_user` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `penilai`
--
ALTER TABLE `penilai`
  MODIFY `id_penilai` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=130;

--
-- AUTO_INCREMENT for table `penilaian`
--
ALTER TABLE `penilaian`
  MODIFY `id_nilai` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2433;

--
-- AUTO_INCREMENT for table `penilai_detail`
--
ALTER TABLE `penilai_detail`
  MODIFY `id_penilai_detail` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=392;

--
-- AUTO_INCREMENT for table `periode`
--
ALTER TABLE `periode`
  MODIFY `id_periode` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `isi_kompetensi`
--
ALTER TABLE `isi_kompetensi`
  ADD CONSTRAINT `FK_isi_kompetensi_jenis_kompetensi` FOREIGN KEY (`id_kompetensi`) REFERENCES `jenis_kompetensi` (`id_kompetensi`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `penilai`
--
ALTER TABLE `penilai`
  ADD CONSTRAINT `FK_penilai_periode` FOREIGN KEY (`id_periode`) REFERENCES `periode` (`id_periode`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_penilai_user` FOREIGN KEY (`nip`) REFERENCES `user` (`nip`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `penilaian`
--
ALTER TABLE `penilaian`
  ADD CONSTRAINT `FK_penilaian_isi_kompetensi` FOREIGN KEY (`id_isi`) REFERENCES `isi_kompetensi` (`id_isi`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_penilaian_penilai_detail` FOREIGN KEY (`id_penilai_detail`) REFERENCES `penilai_detail` (`id_penilai_detail`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `penilai_detail`
--
ALTER TABLE `penilai_detail`
  ADD CONSTRAINT `FK_penilai_detail_penilai` FOREIGN KEY (`id_penilai`) REFERENCES `penilai` (`id_penilai`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_penilai_detail_user` FOREIGN KEY (`nip`) REFERENCES `user` (`nip`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `FK_user_jenis_user` FOREIGN KEY (`id_jenis_user`) REFERENCES `jenis_user` (`id_jenis_user`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
